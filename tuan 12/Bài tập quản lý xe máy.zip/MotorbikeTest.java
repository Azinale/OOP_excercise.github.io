public class MotorbikeTest.java
{
    public static void inputMotorbike (ArrayList<Motorbike> motorbikes, int n)
	{
	}
	public static void ouputMotorbike (ArrayList<Motorbike> motorbikes)
	{
		
	}
	public static ArrayList<Motorbike> search (String manu, ArrayList<Motorbike> motorbikes)
	{
		
	}
	public static ArrayList<Motorbike> maxWeight (ArrayList<Motorbike> motorbikes)
	{
		
	}
	public static ArrayList<Motorbike> minQuanlity (ArrayList<Motorbike> motorbikes)
	{
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}
}